//
//  PlayerViewController.swift
//  VideoPlayer
//
//  Created by sarath kumar on 27/03/20.
//  Copyright © 2020 sarath kumar. All rights reserved.
//

import UIKit
import AVFoundation

class PlayerViewController: UIViewController {
    
    var selectedIndex: Int?
    var videosListArray = [VideoList]()
    var videoSelectedItem: VideoList?
    
    var relatedVideoListArray = [VideoList]()
    var player: AVPlayer!
    var playerLayer: AVPlayerLayer!
    var isVideoPlaying: Bool = false
    
    var videoArray = [PlayTime]()
    var seekTime = Double()
    
    let activityIndicatorView: UIActivityIndicatorView = {
        let inticator = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.large)
           inticator.translatesAutoresizingMaskIntoConstraints = false
           inticator.startAnimating()
           return inticator
       }()
    
    let chatTextView: UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.textColor = UIColor.black
        textField.text = "Enter your Command"
        textField.font = UIFont.boldSystemFont(ofSize: 13)
        textField.borderStyle = .roundedRect
        return textField
    }()
    
    @IBOutlet weak var relatedVideosTableView: UITableView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var dismissBarButtonItem: UIBarButtonItem!
    
    @IBOutlet weak var descriptionView: UIView!
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var playPauseButton: UIButton!
    @IBOutlet weak var currentTimeLabel: UILabel!
    @IBOutlet weak var durationTimeLabel: UILabel!
    @IBOutlet weak var timeSlider: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        containerView.addSubview(activityIndicatorView)
        activityIndicatorView.centerXAnchor.constraint(equalTo: self.containerView.centerXAnchor).isActive = true
        activityIndicatorView.centerYAnchor.constraint(equalTo: self.containerView.centerYAnchor).isActive = true
        
        videoView.addSubview(chatTextView)
        chatTextView.leftAnchor.constraint(equalTo: self.videoView.leftAnchor, constant: 8).isActive = true
        chatTextView.bottomAnchor.constraint(equalTo: self.videoView.bottomAnchor, constant: -2).isActive = true
        chatTextView.widthAnchor.constraint(equalToConstant: 200).isActive = true
        chatTextView.heightAnchor.constraint(equalToConstant: 24).isActive = true
        
        let containerGesture = UITapGestureRecognizer(target: self, action: #selector(containerViewAction))
        containerView.addGestureRecognizer(containerGesture)
        containerView.isUserInteractionEnabled = true
        
        let videoViewGesture = UITapGestureRecognizer(target: self, action: #selector(videoViewAction))
        videoView.addGestureRecognizer(videoViewGesture)
        videoView.isUserInteractionEnabled = true
        
        setupUI()
        fetchPlayTime()
        loadPlayer()
        loadData()
    }
    
    override func viewDidLayoutSubviews() {
        playerLayer.frame = videoView.layer.bounds
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if UIDevice.current.orientation.isLandscape {
            descriptionView.isHidden = true
            relatedVideosTableView.isHidden = true
        } else {
            descriptionView.isHidden = false
            relatedVideosTableView.isHidden = false
        }
    }
    
    //MARK: - Custom Methods
    func createPlayTime()
    {
        for item in videoArray {
            if item.id == videoSelectedItem?.id {
                PresistenceManager.delete(item)
            }
        }
        let playtime = PlayTime(context: PresistenceManager.context)
        playtime.id = videoSelectedItem?.id
        playtime.seekTime = self.timeSlider.value
        PresistenceManager.saveContext()
    }
    
    func fetchPlayTime()
    {
        print("seek Time: \(seekTime)")
        let playtime = PresistenceManager.fetch(PlayTime.self)
        self.videoArray = playtime
        
        for item in self.videoArray {
            if item.id == videoSelectedItem?.id {
                seekTime = Double(item.seekTime)
                print("seek Time after: \(seekTime)")
            }
        }
        
    }
    
    func loadPlayer()
    {
        let url = URL(string: videoSelectedItem!.url)
        player = AVPlayer(url: url!)
        player.currentItem?.addObserver(self, forKeyPath: "duration", options: [.new, .initial], context: nil)
        player?.addObserver(self, forKeyPath: "currentItem.loadedTimeRanges", options: .new, context: nil)
        playerLayer = AVPlayerLayer(player: player)
        let myTime = CMTime(seconds: seekTime, preferredTimescale: 60000)
        player.seek(to: myTime, toleranceBefore: .zero, toleranceAfter: .zero)
        playerLayer.videoGravity = .resize
        videoView.layer.addSublayer(playerLayer)
        videoView.addSubview(containerView)
        containerView.backgroundColor = UIColor(red: 0/255, green: 0/255, blue: 0/255, alpha: 0.5)
        playPauseButton.layer.cornerRadius = 5
        
        addTimeObserver()
    }
    
    func loadData()
    {
        for item in videosListArray {
            if item.id != videoSelectedItem?.id {
                relatedVideoListArray.append(item)
            }
        }
        relatedVideosTableView.reloadData()
    }
    
    func setupUI()
    {
        self.titleLabel.text = videoSelectedItem?.title
        self.descriptionLabel.text = videoSelectedItem?.description
    }
    
    func addTimeObserver()
    {
        NotificationCenter.default.addObserver(self,
        selector: #selector(playerItemDidReachEnd),
                  name: NSNotification.Name.AVPlayerItemDidPlayToEndTime,
                  object: nil)
        let intervel = CMTime(seconds: 0.5, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        let mainQueue = DispatchQueue.main
        _ = player.addPeriodicTimeObserver(forInterval: intervel, queue: mainQueue, using: { [weak self] time in
            guard let currentItem = self?.player.currentItem else { return }
            guard currentItem.status.rawValue == AVPlayerItem.Status.readyToPlay.rawValue else {return}
            guard currentItem.duration >= CMTime.zero else { return }
            self?.timeSlider.maximumValue = Float(currentItem.duration.seconds)
            self?.timeSlider.minimumValue = 0.0
            self?.timeSlider.value = Float(currentItem.currentTime().seconds)
            self?.currentTimeLabel.text = self?.getTimeString(from: currentItem.currentTime())
        })
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "duration", let duration = player.currentItem?.duration.seconds, duration > 0.0 {
            self.durationTimeLabel.text = getTimeString(from: player.currentItem!.duration)
        }
        if keyPath == "currentItem.loadedTimeRanges" {
                    activityIndicatorView.stopAnimating()
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
//                        self.containerView.isHidden = true
//                    }
                }
    }
    
    @objc func playerItemDidReachEnd(notification: NSNotification) {
        relatedVideoListArray.append(videoSelectedItem!)
        videoSelectedItem = relatedVideoListArray.first
        relatedVideoListArray.removeFirst()
        seekTime = 0.0
        setupUI()
        activityIndicatorView.startAnimating()
        loadPlayer()
        DispatchQueue.main.async {
            self.relatedVideosTableView.reloadData()
        }
        player.play()
    }
    
    func getTimeString(from time: CMTime) -> String {
        let totalSeconds = CMTimeGetSeconds(time)
        let hours = Int(totalSeconds/3600)
        let minutes = Int(totalSeconds/60) % 60
        let seconds = Int(totalSeconds
            .truncatingRemainder(dividingBy: 60))
        
        if hours > 0 {
            return String(format: "%i:%02i:%02i", arguments: [hours,minutes,seconds])
        } else {
            return String(format: "%02i:%02i", arguments: [minutes,seconds])
        }
    }
    
    //MARK: - Button Methods
    
    @IBAction func playPauseButtonAction(_ sender: Any)
    {
        if isVideoPlaying {
            player.pause()
            playPauseButton.setTitle("Play", for: .normal)
        } else {
            player.play()
            playPauseButton.setTitle("Pause", for: .normal)
        }
        
        isVideoPlaying = !isVideoPlaying
    }
    
    @IBAction func timeSliderValueChangedAction(_ sender: UISlider) {
        
        player.seek(to: CMTimeMake(value: Int64(sender.value*1000), timescale: 1000))
    }
    
    @IBAction func dismissBarButtonAction(_ sender: Any) {
        
        createPlayTime()
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func containerViewAction() {
        
        if containerView.isHidden == false {
            containerView.isHidden = true
        }
        
    }
    
    @objc func videoViewAction() {
        if containerView.isHidden  {
            containerView.isHidden = false
        }
        
    }
}

extension PlayerViewController: UITableViewDataSource, UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.relatedVideoListArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = relatedVideosTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? PlayerTableViewCell else
        {
            fatalError("table view is not loaded")
        }
        cell.cellBackgroundView.layer.cornerRadius = 5
        cell.cellBackgroundView.clipsToBounds = true
        
        let videoItem = self.relatedVideoListArray[indexPath.row]
        
        cell.titleLabel.text = videoItem.title
        cell.descriptionLabel.text = videoItem.description
        WebService().getImageFromUrl(url: videoItem.thumb, completion: { image in
            print(image)
            DispatchQueue.main.async {
                cell.thumpImageView.image = image
            }
        })
        
        return cell
    }
    
    
}
