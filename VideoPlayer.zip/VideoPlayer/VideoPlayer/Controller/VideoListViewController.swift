//
//  VideoListViewController.swift
//  VideoPlayer
//
//  Created by sarath kumar on 27/03/20.
//  Copyright © 2020 sarath kumar. All rights reserved.
//

import UIKit

class VideoListViewController: UIViewController {
    
    @IBOutlet weak var videosTableView: UITableView!
    
    var videoListItems = [VideoList]()

    override func viewDidLoad() {
        super.viewDidLoad()

        navigationController?.navigationBar.prefersLargeTitles = true
        callWebService()
    }
    
    //MARK: - CustomMethods
    
    func callWebService() {
        WebService().getVideoItems(url: "https://interview-e18de.firebaseio.com/media.json?print=pretty") { videosList in
            if let videosList = videosList {
               // self.videosListVM = VideosListViewModel(videosList: videosList)
                self.videoListItems.append(contentsOf: videosList)
            }
            DispatchQueue.main.async {
               self.videosTableView.reloadData()
            }
        }
    }

}

extension VideoListViewController: UITableViewDelegate,UITableViewDataSource
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.videoListItems.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 200
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        guard let cell = videosTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? VideosListTableViewCell else
        {
            fatalError("table view is not loaded")
        }
        cell.titleBackGroundView.backgroundColor = UIColor(red: 0/255, green: 0/255, blue: 0/255, alpha: 0.5)
        cell.cellBackgroundView.layer.cornerRadius = 5
        cell.cellBackgroundView.clipsToBounds = true
        
        //  let videoVM = self.videosListVM!.videosListAtIndex(indexPath.row)
        let videoItem = self.videoListItems[indexPath.row]
        
        cell.descriptionLabel.text = videoItem.description
        cell.titleLabel.text = videoItem.title
        
        WebService().getImageFromUrl(url: videoItem.thumb, completion: { image in
            DispatchQueue.main.async {
                cell.thumpImageView.image = image
            }
        })
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        videosTableView.deselectRow(at: indexPath, animated: true)
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "PlayerViewController") as? PlayerViewController
        vc?.videosListArray = videoListItems
        vc?.videoSelectedItem = videoListItems[indexPath.row]
        let navController = UINavigationController(rootViewController: vc!)
        navController.modalPresentationStyle = .fullScreen
        self.present(navController,animated:true)
    }
}
