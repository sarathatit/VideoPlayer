//
//  PlayTime+CoreDataClass.swift
//  VideoPlayer
//
//  Created by sarath kumar on 29/03/20.
//  Copyright © 2020 sarath kumar. All rights reserved.
//
//

import Foundation
import CoreData


public class PlayTime: NSManagedObject {

}
