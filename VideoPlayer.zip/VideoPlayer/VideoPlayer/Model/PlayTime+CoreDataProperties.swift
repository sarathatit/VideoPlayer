//
//  PlayTime+CoreDataProperties.swift
//  VideoPlayer
//
//  Created by sarath kumar on 29/03/20.
//  Copyright © 2020 sarath kumar. All rights reserved.
//
//

import Foundation
import CoreData


extension PlayTime {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<PlayTime> {
        return NSFetchRequest<PlayTime>(entityName: "PlayTime")
    }

    @NSManaged public var id: String?
    @NSManaged public var seekTime: Float

}
