//
//  VideoList.swift
//  VideoPlayer
//
//  Created by sarath kumar on 27/03/20.
//  Copyright © 2020 sarath kumar. All rights reserved.
//

import Foundation

struct VideoList: Decodable {
    
     var description: String
     var id: String
     var thumb: String
     var title: String
     var url: String
}
