//
//  WebService.swift
//  VideoPlayer
//
//  Created by sarath kumar on 27/03/20.
//  Copyright © 2020 sarath kumar. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage

class WebService: NSObject {
    
    func getVideoItems(url: String, completion: @escaping ([VideoList]?) -> Void) {
        
        AF.request(url).response { response in
            if let responseData = response.data {
                print(responseData)
                let videoList = try? JSONDecoder().decode([VideoList].self, from: responseData)
                if let videoLists = videoList {
                    completion(videoLists)
                }
            }
        }
    }
    
    func getImageFromUrl(url: String, completion: @escaping (_ image: UIImage) -> (Void)) {
       AF.request(url).responseImage { response in
            if case .success(let image) = response.result {
                completion(image)
            }
        }
    }

}
